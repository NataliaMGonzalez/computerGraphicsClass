Versión Hello World de THREEJS para el manejo de eventos del movimiento del mouse
Important: Camera's Orbit controls are disabled!

Instructions:
Move mouse on the canvas in order to move the cube throughout the scene

main.js:
// SCENE HIERARCHY
    scene.add(mesh);
    mesh.visible = false;

// EVENT LISTENERES & HANDLERS
renderer.domElement.addEventListener("pointermove", (ev) => {
        // Client Coordinates
        let xClient = ev.clientX;
        let yClient = ev.clientY;

        // Device Coordinates (NDC)
        let xDevice = (xClient / window.innerWidth) * 2 - 1;
        let yDevice = -(yClient / window.innerHeight) * 2 + 1;

        let vDev = new THREE.Vector3(xDevice, yDevice, 0.5);    // 0.5 is in order to no divide by zero!
        vDev.unproject( camera );
        vDev.sub(camera.position).normalize();
        var distance = - camera.position.z / vDev.z;

        // World Coordinates
        let vWorld = new THREE.Vector3();
        vWorld.copy(camera.position).add(vDev.multiplyScalar(distance));
        mesh.position.set(vWorld.x, vWorld.y, vWorld.z);
     }, false);

    // DRAW SCENE IN A RENDER LOOP (ANIMATION)
    renderLoop();
}

More info:
Mouse click issue:
https://github.com/mrdoob/three.js/issues/20294

Pointer Events API:
https://developer.mozilla.org/en-US/docs/Web/API/Pointer_events

Canvas to World-space coordintaes Issue:
https://stackoverflow.com/questions/13055214/mouse-canvas-x-y-to-three-js-world-x-y-z
https://jsfiddle.net/f2Lommf5/951/

Coordinate Systems in the Graphics Pipeline

https://www.students.cs.ubc.ca/~cs-314/notes/pipeline.html
https://learnopengl.com/Getting-started/Coordinate-Systems