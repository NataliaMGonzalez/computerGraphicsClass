import * as THREE from "/build/three.module.js";
import Stats from "/js/jsm/libs/stats.module.js";
import {OrbitControls} from "/js/jsm/controls/OrbitControls.js";

"use strict";

let renderer, scene, camera, mesh, stats, cameraControls;

function init(event) {
    // RENDERER ENGINE
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // SCENE
    scene = new THREE.Scene();

    // CAMERA
    let fovy = 60.0;    // Field ov view
    let aspectRatio = window.innerWidth / window.innerHeight;
    let nearPlane = 0.1;
    let farPlane = 10000.0;
    camera = new THREE.PerspectiveCamera(fovy, aspectRatio, nearPlane, farPlane);
    camera.position.set(0, 0, 3);
    //cameraControls = new OrbitControls(camera, renderer.domElement);
            
    // MODEL
    let geometry = new THREE.BoxGeometry();
    let material = new THREE.MeshBasicMaterial({wireframe: true});
    mesh = new THREE.Mesh(geometry, material);

    // SCENE HIERARCHY
    scene.add(mesh);
    mesh.visible = false;

    // SETUP STATS
    stats = new Stats();
    stats.showPanel(0); // 0: fps, 1: ms, 2: mb, 3+: custom
    document.body.appendChild(stats.dom);

    // DRAW SCENE IN A RENDER LOOP (ANIMATION)
    renderLoop();
}

function renderLoop() {
    stats.begin();
    renderer.render(scene, camera); // DRAW SCENE
    updateScene();
    stats.end();
    stats.update();
    requestAnimationFrame(renderLoop);
}

function updateScene() {
    
}

// EVENT LISTENERS & HANDLERS
document.addEventListener("DOMContentLoaded", init);

window.addEventListener("resize", (ev) => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    //cameraControls.update();
    }, false);

document.addEventListener("pointermove", (event) => {
    mesh.visible = true;
    // Client Coordinates
    let xClient = event.clientX;
    let yClient = event.clientY;

    // Device Coordinates (NDC)
    let xDevice = (xClient / window.innerWidth) * 2 - 1;
    let yDevice = -(yClient / window.innerHeight) * 2 + 1;

    // World Coordinates
    let vDev = new THREE.Vector3(xDevice, yDevice, 0.5);
    vDev.unproject( camera );
    vDev.sub(camera.position).normalize();
    var distance = - camera.position.z / vDev.z;
    
    let vWorld = new THREE.Vector3();
    vWorld.copy(camera.position).add(vDev.multiplyScalar(distance));

    mesh.position.set(vWorld.x, vWorld.y, vWorld.z);
 }, false);



	
