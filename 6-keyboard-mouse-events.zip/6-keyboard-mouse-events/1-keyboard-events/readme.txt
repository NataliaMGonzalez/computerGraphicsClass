Versión Hello World de THREEJS para elmanejo de eventos del teclado

Instructions:
up key arrow - Rotate about X CW
down key arrow - Rotate about X CCW
right key arrow - Rotate about Y CCW
left key arrow - Rotate about Y CW

main.js

// EVENT HANDLER
...
function keyUpEventHandler(event) {	
	if(event.keyCode == 37)	// Left Arrow Key
	{
		mesh.rotation.y = mesh.rotation.y - 2 * Math.PI / 180;
	}
	else if(event.keyCode == 38)	// Up Arrow Key
	{
		mesh.rotation.x = mesh.rotation.x - 2 * Math.PI / 180;
	}
	else if(event.keyCode == 39)	// Right Arrow Key
	{
		mesh.rotation.y = mesh.rotation.y + 2 * Math.PI / 180;
	}
	else if(event.keyCode == 40)	// Down Arrow Key
	{
		mesh.rotation.x = mesh.rotation.x + 2 * Math.PI / 180;
	}
}

// EVENT LISTENERES
...
document.addEventListener("keyup", keyUpEventHandler, false);


